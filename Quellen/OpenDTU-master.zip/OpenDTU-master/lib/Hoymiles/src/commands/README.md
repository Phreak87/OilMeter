# Class hierarchy

* CommandAbstract
    * DevControlCommand
        * ActivePowerControlCommand
        * PowerControlCommand
    * MultiDataCommand
        * AlarmDataCommand
        * DevInfoAllCommand
        * DevInfoSimpleCommand
        * RealTimeRunDataCommand
        * SystemConfigParaCommand
    * ParaSetCommand
    * SingleDataCommand
        * RequestFrameCommand