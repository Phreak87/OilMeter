// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once

#define STR_HELPER(x) #x
#define STR(x) STR_HELPER(x)