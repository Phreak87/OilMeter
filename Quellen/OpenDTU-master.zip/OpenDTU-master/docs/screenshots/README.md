# OpenDTU Screenshots

here are some screenshots of OpenDTU's web interface.

***

![](01_LiveView.png)

***

![](15_LimitSettings.png)

***

![](16_PowerSettings.png)

***

![](17_InverterInfo.png)

***

![](12_Eventlog.png)

***

![](02_NetworkAdmin.png)

***

![](03_NtpAdmin.png)

***

![](04_MqttAdmin.png)

***

![](05_InverterAdmin.png)

***

![](13_InverterSettings.png)

***

![](22_Security.png)

***

![](06_DtuAdmin.png)

***

![](20_DeviceManager_Pin.png)

***

![](21_DeviceManager_Display.png)

***

![](14_ConfigManagement.png)

***

![](07_FirmwareUpgrade.png)

***

![](19_Reboot.png)

***

![](11_SystemInfo.png)

***

![](08_NetworkInfo.png)

***

![](09_NtpInfo.png)

***

![](10_MqttInfo.png)

***

![](18_Console.png)
