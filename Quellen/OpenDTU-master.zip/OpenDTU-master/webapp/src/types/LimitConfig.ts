export interface LimitConfig {
    serial: number;
    limit_value: number;
    limit_type: number;
}