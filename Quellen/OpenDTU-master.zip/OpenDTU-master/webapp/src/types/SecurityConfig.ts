export interface SecurityConfig {
    password: string;
    allow_readonly: boolean;
}