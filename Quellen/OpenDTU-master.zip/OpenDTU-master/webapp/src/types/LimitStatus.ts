export interface LimitStatus {
    limit_relative: number;
    max_power: number;
    limit_set_status: string;
}