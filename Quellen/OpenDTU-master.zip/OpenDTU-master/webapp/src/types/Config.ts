export interface ConfigFileInfo {
    name: string;
}

export interface ConfigFileList {
    configs: Array<ConfigFileInfo>;
}