export interface DtuConfig {
    dtu_serial: number;
    dtu_pollinterval: number;
    dtu_palevel: number;
}