# Screwless housing for Evil Crow Rf v.1

"OldStyle"
The STL files do not contain support structures for 3D printing
You have to find out for yourself how it is best printed. 
I printed it with an SLA printer and had to print the housing parts upright for best printing results.

<img src="https://github.com/joelsernamoreno/EvilCrow-RF/blob/main/3D_Case_Satan/img/V1_CASE_3.jpg"/>

"NewStyle"
Redesigned V1 case for better printability with the same size.(length including cap)

<img src="https://github.com/joelsernamoreno/EvilCrow-RF/blob/main/3D_Case_Satan/img/V1_CASE_New_Style_3.jpg"/>

