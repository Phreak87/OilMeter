The icon is based on the work of SachaD, see https://freesvg.org/water-meter-for-hot-water
License: Public Domain
