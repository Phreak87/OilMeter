The files in this folder are directly copied from the generated mkdocs site folder. 
