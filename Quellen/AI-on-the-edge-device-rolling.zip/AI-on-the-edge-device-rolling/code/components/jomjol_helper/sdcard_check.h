#pragma once

#ifndef COMPONENTS_HELPER_SDCARD_CHECK_H
#define COMPONENTS_HELPER_SDCARD_CHECK_H

#include "../../include/defines.h"

int SDCardCheckRW(void);
bool SDCardCheckFolderFilePresence(void);

#endif /* COMPONENTS_HELPER_SDCARD_CHECK_H */
