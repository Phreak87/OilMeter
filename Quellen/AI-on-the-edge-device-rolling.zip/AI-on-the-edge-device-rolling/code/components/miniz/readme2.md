The files in this folder are a direct extraction of the miniz release from https://github.com/richgel999/miniz/releases

It should be possible to include the repo directly as a submodule, how ever it causes various issues. See also
 - https://github.com/richgel999/miniz/issues/145
 - https://github.com/espressif/esptool/pull/500#issuecomment-574879468

 For sumplicity we therefore use the release files as suggested in the readme.
 Additionally we added the CMakeLists.txt and this readme.