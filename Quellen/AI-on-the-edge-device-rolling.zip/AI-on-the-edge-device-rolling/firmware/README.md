# Firmware
The firmware got moved to the [Release page](https://github.com/jomjol/AI-on-the-edge-device/releases).

# Installation Guide

You find the complete installation guide at https://jomjol.github.io/AI-on-the-edge-device-docs/Installation/
